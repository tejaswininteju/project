package com.jspiders.spring.repository;

import org.springframework.data.repository.CrudRepository;

import com.jspiders.spring.entities.ReturnLinks;

public interface ReturnLinksRepository extends CrudRepository<ReturnLinks, String> {

}
